package simulator;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.UIManager;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.theme.SubstanceTerracottaTheme;

public class Main {
	public static void main(String[] args)
	{
		UI myUI = new UI();
		myUI.initUI();
		
		


		
		
		
		
		
		
//		Simulator simu = new Simulator();
//		simu.readFileByLines(simu.fileName);
//		simu.runSimulator();
//		
//		simu.instructions.checkInstr();
//		simu.addReserv.checkReserv();
//		simu.addFunc.checkFunc();
//		simu.reg.checkFu();
		
		

		
//		simu.instructions.checkInstr();
//		simu.loadReserv.checkReserv();
//		simu.loadFunc.checkFunc();
//		simu.reg.checkFu();
		
	}
}